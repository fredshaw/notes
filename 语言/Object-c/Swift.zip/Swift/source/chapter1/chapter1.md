# 欢迎使用 Swift

在本章中您将了解 Swift 的特性和开发历史，并对 Swift 有一个初步的了解。

