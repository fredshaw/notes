> Swift 中文翻译组：364279588（要求对翻译感兴趣）

> Swift 兴趣交流群：307017261

> [Swift 开发者社区](http://swiftist.org)

<!-- -->
> 如果你觉得这个项目不错，请[点击Star一下](https://github.com/numbbbbb/the-swift-programming-language-in-chinese)，您的支持我们最大的动力。

# The Swift Programming Language 中文版

###这一次，让中国和世界同步

现在是6月12日凌晨4:38，我用了整整一晚上的时间来进行最后的校对，终于可以在12日拿出一个可以发布的版本。

9天时间，1317个 Star，310个 Fork，超过30人参与翻译和校对工作，项目最高排名GitHub总榜第4。

设想过很多遍校对完成时的场景，仰天大笑还是泪流满面？真正到了这一刻才发现，疲倦已经不允许我有任何情绪。

说实话，刚开始发起项目的时候完全没想到会发展成今天这样，我一度计划自己一个人翻译完整本书。万万没想到，会有这么多的人愿意加入并贡献出自己的力量。

coverxit发给我最后一份文档的时候说，我要去背单词了，我问他，周末要考六级？他说是的。

pp-prog告诉我，这几天太累了，校对到一半睡着了，醒来又继续做。2点17分，发给我校对完成的文档。

lifedim说他平时12点就会睡，1点47分，发给我校对后的文档。

团队里每个人都有自己的事情，上班、上学、创业，但是我们只用了9天就完成整本书的翻译。我不知道大家付出了多少，牺牲了多少，但是我知道，他们的付出必将被这些文字记录下来，即使再过10年，20年，依然熠熠生辉，永不被人遗忘。

全体人员名单（排名不分先后）：

- numbbbbb
- coverxit
- wh1100717
- TimothyYe
- honghaoz
- Hawstein
- JaySurplus
- stanzhai
- lyuka
- geek5nan
- xielingwang
- yankuangshi
- dabing1022
- siemenliu
- fd5788
- youkugems
- haolloyin
- superkam
- vclwei
- sg552
- bzsy
- pyanfield
- ericzyh
- 088haizi
- viztor
- pp-prog
- baocaixiong
- marsprince
- shinyzhu
- happyming
- menlongsheng
- zq54zquan
- Evilcome
- lslxdx
- yeahdongcn
- zqp

